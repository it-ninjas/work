<!--suppress CheckEmptyScriptTag -->

# Java Exercises - Variablen und bedingte Anweisungen

Mit diesen Übungen kannst du dein Wissen über bedingte Ausführung vertiefen.

#### Voraussetzung

- Du verstehst und kennst die verschiedenen Conditional Statements.
- Du weisst, wann und wie welches Conditional Statement eingesetzt werden sollte.

<!--instructions-->

## Aufgabe 1 - Zahlenvergleich

Passe die folgende Methode an. Vergleiche die beiden Zahlen 'zahl1' und 'zahl2' und gib das Resultat des Vergleichs auf
auf der Konsole aus:

- `Zahl1(value1) ist kleiner als Zahl2(value2)`
- `Zahl1(value1) ist grösser als Zahl2(value2)`
- `Zahl1(value1) ist gleich gross wie Zahl2(value2)`

Wobei in der Ausgabe `value1` und `value2` durch die tatsächlichen Werte ersetzt werden sollen.

```java
    public static void compareNumbers(int number1, int number2) {

        // IT-Ninja: Füge hier Deinen Code ein:

    }
```

::src(src/main/java/ch/itninja/labs/basicexercises/CompareNumbers.java)

**Beispiel 1:**

Eingabe:

```console
CompareNumbers.compareNumbers(-1, 5);
```

Ausgabe:

```console
Zahl1(-1) ist kleiner als Zahl2(5)
```

**Beispiel 2:**

Eingabe:

```console
CompareNumbers.compareNumbers(23, 7);
```

Ausgabe:

```console
Zahl1(23) ist grÃ¶sser als Zahl2(7)
```

**Beispiel 3:**

Eingabe:

```console
CompareNumbers.compareNumbers(47, 47);
```

Ausgabe:

```console
Zahl1(47) ist gleich gross wie Zahl2(47)
```

**Beispiel 4:**

Eingabe:

```console
CompareNumbers.compareNumbers(0, 0);
```

Ausgabe:

```console
Zahl1(0) ist gleich gross wie Zahl2(0)
```

## Aufgabe 2 - Schaltjahr

Passe die folgende Methode an. Stell fest, ob das übergebene Jahr ein Schaltjahr ist (gemäss gregorianischer Kalender).
Gib auf der Konsole das Resultat aus:

- `Das Jahr year ist ein Schaltjahr gemäss gregorianischem Kalender`
- `Das Jahr year ist kein Schaltjahr gemäss gregorianischem Kalender`

Wobei in der Ausgabe `year` durch das tatsächliche Jahr ersetzt werden soll.
Falls das Jahr ein Schaltjahr gemäss gregorianischem Kalender ist, soll die Methode `true` zurückgeben, andernfalls
`false`.

> Verwende keine logischen Ausdrücke zur Berechnung des Schaltjahres. Nutze stattdessen if-else- und else-if Anweisungen.

```java
    public static boolean isLeapYear(int year) {

        // IT-Ninja: Füge hier Deinen Code ein:

    }
```

::src(src/main/java/ch/itninja/labs/basicexercises/LeapYear.java)

**Beispiel 1:**

Eingabe:

```console
boolean result = LeapYear.isLeapYear(1200);
```

Ausgabe:

```console
Das Jahr 1200 ist kein Schaltjahr gemÃ¤ss gregorianischem Kalender
```

**Beispiel 2:**

Eingabe:

```console
boolean result = LeapYear.isLeapYear(1996);
```

Ausgabe:

```console
Das Jahr 1996 ist ein Schaltjahr gemÃ¤ss gregorianischem Kalender
```

**Beispiel 3:**

Eingabe:

```console
boolean result = LeapYear.isLeapYear(1900);
```

Ausgabe:

```console
Das Jahr 1900 ist kein Schaltjahr gemÃ¤ss gregorianischem Kalender
```

**Beispiel 4:**

Eingabe:

```console
boolean result = LeapYear.isLeapYear(2000);
```

Ausgabe:

```console
Das Jahr 2000 ist ein Schaltjahr gemÃ¤ss gregorianischem Kalender
```

**Beispiel 5:**

Eingabe:

```console
boolean result = LeapYear.isLeapYear(2021);
```

Ausgabe:

```console
Das Jahr 2021 ist kein Schaltjahr gemÃ¤ss gregorianischem Kalender
```

**Beispiel 6:**

Eingabe:

```console
boolean result = LeapYear.isLeapYear(2024);
```

Ausgabe:

```console
Das Jahr 2024 ist ein Schaltjahr gemÃ¤ss gregorianischem Kalender
```

**Beispiel 7:**

Eingabe:

```console
boolean result = LeapYear.isLeapYear(2100);
```

Ausgabe:

```console
Das Jahr 2100 ist kein Schaltjahr gemÃ¤ss gregorianischem Kalender
```

**Beispiel 8:**

Eingabe:

```console
boolean result = LeapYear.isLeapYear(2400);
```

Ausgabe:

```console
Das Jahr 2400 ist ein Schaltjahr gemÃ¤ss gregorianischem Kalender
```

**Beispiel 9:**

Eingabe:

```console
boolean result = LeapYear.isLeapYear(2023);
```

Ausgabe:

```console
Das Jahr 2023 ist kein Schaltjahr gemÃ¤ss gregorianischem Kalender
```
