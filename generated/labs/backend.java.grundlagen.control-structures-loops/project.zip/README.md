<!--suppress CheckEmptyScriptTag -->

# Java Exercises - Loops

Mit diesen Übungen kannst du dein Wissen über die Befehle `for`, `while` und `do` vertiefen.

#### Voraussetzung

- Du kennst die Befehle `for`, `while` und `do`.

<!--instructions-->

## Aufgabe 1 - Summe aller durch 8 teilbaren Zahlen von 1 bis 100

Passe die folgende Methode an. Zähle alle Zahlen von **1 bis 100** zusammen, welche durch **8** teilbar sind und gib das
Resultat auf der Konsole aus:

- `Die Summe aller durch 8 teilbaren Zahlen von 1 bis 100 beträgt 624.`

```java
    public static void sumDivisibleByEightFixedRange() {

        // IT-Ninja: Füge hier Deinen Code ein:
    }
```

::src(src/main/java/ch/itninja/labs/basicexercises/NumberHelper.java)

**Beispiel:**

Eingabe:

```console
NumberHelper.sumDivisibleByEightFixedRange()
```

Ausgabe:

```console
Die Summe aller durch 8 teilbaren Zahlen von 1 bis 100 betrÃ¤gt 624.
```

## Aufgabe 2 - Summe aller durch X teilbaren Zahlen

Passe die folgende Methode an. Zähle alle Zahlen von `min` bis `max` zusammen, welche durch `divisor` teilbar sind und gib das
Resultat auf der Konsole aus:

- `Die Summe aller durch [divisor] teilbaren Zahlen von [min] bis [max] beträgt [result].`

> Abgrenzung: Wenn `max` kleiner als `min` ist oder wenn `divisor` kleiner gleich 0 ist, soll folgender Text auf der
> Konsole ausgegeben werden: `Berechnung mit diesen Werten nicht möglich`


```java
    public static void sumDivisibleBy(int min, int max, int divisor) {

        // IT-Ninja: Füge hier Deinen Code ein:
    }
```

::src(src/main/java/ch/itninja/labs/basicexercises/NumberHelper.java)

**Beispiel 1:**

Eingabe:

```console
NumberHelper.sumDivisibleBy(10, 30, 7);
```

Ausgabe:

```console
Die Summe aller durch 7 teilbaren Zahlen von 10 bis 30 betrÃ¤gt 63.
```

**Beispiel 2:**

Eingabe:

```console
NumberHelper.sumDivisibleBy(30, 10, 7);
```

Ausgabe:

```console
Berechnung mit diesen Werten nicht mÃ¶glich.
```

## Aufgabe 3 - Summe gemeinsames Vielfaches zweier Zahlen

Passe die folgende Methode an. Zähle alle Zahlen von `min` bis `max` zusammen, welche ein gemeinsames Vielfaches von den
beiden Zahlen `number1` und `number2`sind und gib das Resultat auf der Konsole aus:

- `Summe der Zahlen von [min] bis [max], die ein gemeinsames Vielfache von [number1] und [number2] sind: [result].`

> Abgrenzung: Wenn `max` kleiner als `min` ist oder wenn eine der Zahlen `number1` oder 'number2' kleiner gleich 0 ist,
> soll folgender Text auf der Konsole ausgegeben werden: `Berechnung mit diesen Werten nicht möglich`


```java
    public static void sumCommonMultiples(int min, int max, int number1, int number2) {

        // IT-Ninja: Füge hier Deinen Code ein:
    }
```

::src(src/main/java/ch/itninja/labs/basicexercises/NumberHelper.java)

**Beispiel 1:**

Eingabe:

```console
NumberHelper.sumCommonMultiples(1, 50, 3, 5);
```

Ausgabe:

```console
Summe der Zahlen von 1 bis 50, die ein gemeinsames Vielfache von 3 und 5 sind: 90.
```

**Beispiel 2:**

Eingabe:

```console
NumberHelper.sumCommonMultiples(1, 100, 4, 6);
```

Ausgabe:

```console
Summe der Zahlen von 1 bis 100, die ein gemeinsames Vielfache von 4 und 6 sind: 432.
```

**Beispiel 3:**

Eingabe:

```console
NumberHelper.sumCommonMultiples(1, 10, 4, 6);
```

Ausgabe:

```console
Summe der Zahlen von 1 bis 10, die ein gemeinsames Vielfache von 4 und 6 sind: 0.
```

**Beispiel 4:**

Eingabe:

```console
NumberHelper.sumCommonMultiples(50, 1, 3, 5);
```

Ausgabe:

```console
Berechnung mit diesen Werten nicht mÃ¶glich.
```

**Beispiel 5:**

Eingabe:

```console
NumberHelper.sumCommonMultiples(15, 15, 3, 5);
```

Ausgabe:

```console
Summe der Zahlen von 15 bis 15, die ein gemeinsames Vielfache von 3 und 5 sind: 15.
```

**Beispiel 6:**

Eingabe:

```console
NumberHelper.sumCommonMultiples(60, 60, 4, 6);
```

Ausgabe:

```console
Summe der Zahlen von 60 bis 60, die ein gemeinsames Vielfache von 4 und 6 sind: 60.
```

**Beispiel 7:**

Eingabe:

```console
NumberHelper.sumCommonMultiples(-30, 30, 6, 10);
```

Ausgabe:

```console
Summe der Zahlen von -30 bis 30, die ein gemeinsames Vielfache von 6 und 10 sind: 0.
```

**Beispiel 8:**

Eingabe:

```console
NumberHelper.sumCommonMultiples(1, 1000, 8, 12);
```

Ausgabe:

```console
Summe der Zahlen von 1 bis 1000, die ein gemeinsames Vielfache von 8 und 12 sind: 20664.
```
