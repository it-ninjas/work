<!--suppress CheckEmptyScriptTag -->

# Java Exercises - Das Switch Statement

Mit diesen Übungen kannst du dein Wissen über den Befehl `switch` vertiefen.

#### Voraussetzung

- Du kennst den `switch` Befehl.

<!--instructions-->

## Aufgabe 1 - Monat ausgeben

Passe die folgende Methode an. Gib abhängig von der Variable `month` den passenden Monat auf der Konsole aus. Der Wert
`1` soll dabei dem Monat `Januar` entsprechen, `2` dem Monat `Februar`, usw. Für Zahlen welche keinem Monat entsprechen
soll `ungültiger Monat` auf der Konsole ausgegeben werden.

```java
    public static void printMonthByNumber(int month) {

        // IT-Ninja: Füge hier Deinen Code ein:

    }
```

::src(src/main/java/ch/itninja/labs/basicexercises/MonthHelper.java)

**Beispiel 1:**

Eingabe:

```console
MonthHelper.printMonthByNumber(1);
```

Ausgabe:

```console
Januar
```

**Beispiel 2:**

Eingabe:

```console
MonthHelper.printMonthByNumber(5);
```

Ausgabe:

```console
Mai
```

**Beispiel 3:**

Eingabe:

```console
MonthHelper.printMonthByNumber(9);
```

Ausgabe:

```console
September
```

**Beispiel 4:**

Eingabe:

```console
MonthHelper.printMonthByNumber(12);
```

Ausgabe:

```console
Dezember
```

**Beispiel 5:**

Eingabe:

```console
MonthHelper.printMonthByNumber(22);
```

Ausgabe:

```console
ungÃ¼ltiger Monat
```

**Beispiel 6:**

Eingabe:

```console
MonthHelper.printMonthByNumber(-3);
```

Ausgabe:

```console
ungÃ¼ltiger Monat
```

## Aufgabe 2 - Wochentag

Passe die folgende Methode an. Gib abhängig von der Variable `weekdayName` auf der Konsole aus, um welchen Wochentag es sich
handelt:

- `Der [weekdayName] ist der [weekday]. Tag in der Woche.`
- `[weekdayName] entspricht keinem bekannten Wochentag.`

Wobei in der Ausgabe `[weekdayName]` durch den Namen des Wochentags ersetzt werden soll und `[weekday]` durch den Tag
der Woche, welche dem Wochentag entspricht. Der Montag soll dabei der erste Tag in der Woche sein.

```java
    public static void printWeekdayNumber(String weekdayName) {

        // IT-Ninja: Füge hier Deinen Code ein:

    }
```

::src(src/main/java/ch/itninja/labs/basicexercises/WeekHelper.java)

**Beispiel 1:**

Eingabe:

```console
WeekHelper.printWeekdayNumber("Freitag");
```

Ausgabe:

```console
Der Freitag ist der 5. Tag in der Woche.
```

**Beispiel 2:**

Eingabe:

```console
WeekHelper.printWeekdayNumber("Donnerstag");
```

Ausgabe:

```console
Der Donnerstag ist der 4. Tag in der Woche.
```

**Beispiel 3:**

Eingabe:

```console
WeekHelper.printWeekdayNumber("Weihnachten");
```

Ausgabe:

```console
Weihnachten entspricht keinem bekannten Wochentag.
```

**Beispiel 4:**

Eingabe:

```console
WeekHelper.printWeekdayNumber("Samstag");
```

Ausgabe:

```console
Der Samstag ist der 6. Tag in der Woche.
```
