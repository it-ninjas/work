<!--suppress CheckEmptyScriptTag -->

# Java Exercises - Exception Handling

Mit diesen Übungen kannst du erste Erfahrungen beim behandeln von Exceptions sammeln.

## Voraussetzungen

- Du kennst `try`, `catch`, `throw`, `throws` und `finally`.

<!--instructions-->

## Aufgabe 1 – Sichere Division

Passe untenstehenden Quellcode an und füge folgende Methode hinzu:

---
**Name der Methode:** *Bestimme selber einen passenden Namen für die Methode*  
**Funktion:** Liefert das Resultat der Divsion von `a` durch `b`. Bei einer Divsion durch 0 wird der Wert
`Integer.MAX_VALUE` zurückgeben.  
**Parameter1:** a [int]  
**Parameter2:** b [int]  
**Rückgabewert:** Resultat der Berechnung [int], `Integer,MAX_VALUE` bei Division durch 0.  
**Bedingungen:** Verwende `try` / `catch`, um Division durch 0 korrekt abzufangen. `if` darf nicht verwendet werden.

---

> Halte die Coding Guidelines ein!

```java
public class Calculator {

    private Calculator() {
        // Prevent instantiation
    }

    // Place here the methode for "Sichere Division".
    
    // IT-Ninja: Füge hier Deinen Code ein:

    // Place here the methode for "Mindestwert sicherstellen".
    
    // IT-Ninja: Füge hier Deinen Code ein:
}
```

::src(src/main/java/ch/itninja/labs/basicexercises/Calculator.java)

Wenn du die Methode implementiert hast, kannst du sie aus `main` aufrufen.

```java
    public static void main(String[] args) {

        // Sample call for "Sichere Division"
        // IT-Ninja: Füge hier Deinen Code ein:

        try {
            int age = 16;
            // Sample call for "Alter prüfen"
            // IT-Ninja: Füge hier Deinen Code ein:
            System.out.printf("Das Alter %d ist gültig.%n", age);
        } catch (IllegalArgumentException e) {
            System.out.println("Fehler: " + e.getMessage());
        }

        // Sample call for "Mindestwert sicherstellen"
        // IT-Ninja: Füge hier Deinen Code ein:
    }
```

::src(src/main/java/ch/itninja/labs/Main.java)

Falls du sie testen willst, kannst du sie aus dem vorbereiteten Test aufrufen.

```java
        try {
            // WHEN
            // Aufruf der Methode für "Sichere Division", welche wir testen wollen (etwas wie: res = methode(a, b);):
            // IT-Ninja: Füge hier Deinen Code ein:
        } finally {
        }
```

::src(src/test/java/ch/itninja/labs/CalculatorTest.java)



## Aufgabe 2 – Alter prüfen

Passe untenstehenden Quellcode an und füge folgende Methode hinzu:

---

**Name der Methode:** *Bestimme selber einen passenden Namen für die Methode*  
**Funktion:** Prüft das Alter und wirft eine `IllegalArgumentException`, wenn das Alter kleiner 0 oder grösser 130 ist.
Für gültige Werte passiert nichts.  
**Parameter1:** age [int]  
**Rückgabewert:** keiner, `IllegalArgumentException` wenn Alter ausserhalb des erlaubten Bereichs ist.  

---

> Halte die Coding Guidelines ein!

```java
public class AgeValidator {

    // IT-Ninja: Füge hier Deinen Code ein:

    private AgeValidator() {
        // Prevent instantiation
    }

    // IT-Ninja: Füge hier Deinen Code ein:
}
```

::src(src/main/java/ch/itninja/labs/basicexercises/AgeValidator.java)

Wenn du die Methode implementiert hast, kannst du sie aus `main` aufrufen.

```java
    public static void main(String[] args) {

        // Sample call for "Sichere Division"
        // IT-Ninja: Füge hier Deinen Code ein:

        try {
            int age = 16;
            // Sample call for "Alter prüfen"
            // IT-Ninja: Füge hier Deinen Code ein:
            System.out.printf("Das Alter %d ist gültig.%n", age);
        } catch (IllegalArgumentException e) {
            System.out.println("Fehler: " + e.getMessage());
        }

        // Sample call for "Mindestwert sicherstellen"
        // IT-Ninja: Füge hier Deinen Code ein:
    }
```

::src(src/main/java/ch/itninja/labs/Main.java)

Falls du sie testen willst, kannst du sie aus dem vorbereiteten Test aufrufen.

```java
        try {
            // WHEN
            // Aufruf der Methode für "Sichere Division", welche wir testen wollen (etwas wie: res = methode(a, b);):
            // IT-Ninja: Füge hier Deinen Code ein:
        } catch (IllegalArgumentException e) {
            excptionOccured = true;
            exceptionMessage = e.getMessage();
        }
```

::src(src/test/java/ch/itninja/labs/AgeValidatorTest.java)



## Aufgabe 3 – Mindestwert sicherstellen

Passe untenstehenden Quellcode an und füge folgende Methode hinzu:

---

**Name der Methode:** *Bestimme selber einen passenden Namen für die Methode*  
**Funktion:** Dividiert `a` durch `b` und danach `c` durch `d`. Das Resultat wird jeweils zum Total hinzugefügt. Fehler
werden mit **einem einzigen** `try` / `catch` abgefangen. Im `finally`-Block wird abschliessend sichergestellt, dass das
Total mindestens 100 beträgt.  
**Parameter1:** a [int]  
**Parameter2:** b [int]  
**Parameter3:** c [int]  
**Parameter4:** b [int]  
**Rückgabewert:** Total der Berechnung [int]  

---
Bei dieser Aufgabe ist es wichtig, dass du die Funktion genau umsetzt auch wenn sie eigentlich keinen Sinn macht oder
besser implementiert werden könnte. 

> Halte die Coding Guidelines trotzdem ein!

```java
public class Calculator {

    private Calculator() {
        // Prevent instantiation
    }

    // Place here the methode for "Sichere Division".
    
    // IT-Ninja: Füge hier Deinen Code ein:

    // Place here the methode for "Mindestwert sicherstellen".
    
    // IT-Ninja: Füge hier Deinen Code ein:
}
```

::src(src/main/java/ch/itninja/labs/basicexercises/Calculator.java)

Wenn du die Methode implementiert hast, kannst du sie aus `main` aufrufen.

```java
    public static void main(String[] args) {

        // Sample call for "Sichere Division"
        // IT-Ninja: Füge hier Deinen Code ein:

        try {
            int age = 16;
            // Sample call for "Alter prüfen"
            // IT-Ninja: Füge hier Deinen Code ein:
            System.out.printf("Das Alter %d ist gültig.%n", age);
        } catch (IllegalArgumentException e) {
            System.out.println("Fehler: " + e.getMessage());
        }

        // Sample call for "Mindestwert sicherstellen"
        // IT-Ninja: Füge hier Deinen Code ein:
    }
```

::src(src/main/java/ch/itninja/labs/Main.java)

Falls du sie testen willst, kannst du sie aus dem vorbereiteten Test aufrufen.

```java
        try {
            // WHEN
            // Aufruf der Methode für "Mindestwert sicherstellen", welche wir testen wollen (etwas wie: min = methode(a, b, c);):
            // IT-Ninja: Füge hier Deinen Code ein:
        } finally {
        }
```

::src(src/test/java/ch/itninja/labs/CalculatorTest.java)


