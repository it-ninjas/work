<!--suppress CheckEmptyScriptTag -->

# Java Exercises - Regex

Mit diesen Übungen kannst du dein Wissen zum Thema Regex vertiefen.

#### Voraussetzung

- Ich kann mit Regex Zeichenketten im Text erkennen und extrahieren.
- Ich verstehe, wie man Regex schrittweise und sicher testet.

<!--instructions-->

## Aufgabe 1 - E-Mail-Adressen aus einem Text extrahieren
Schreibe eine Regex, die alle E-Mail-Adressen in einem Text findet. Nutze die bereitgestellte Beispieldatei `data/mixed.txt`.
</itninja description>

- Beispieleingabe: `Meine Adresse: max.mustermann@example.com; Info: test@mail.de`
- Erwartete Treffer: `["max.mustermann@example.com", "test@mail.de"]`

```java
    /**
     * Build a Pattern that matches email-like addresses.
     * Tip: local-part + "@" + domain + TLD of length >= 2.
     */
    public static Pattern buildEmailPattern() {
        // TODO: implement
        return Pattern.compile("");
    }
```

::src(src/main/java/ch/itninja/labs/regex/RegexTasks.java)

---

## Aufgabe 2 - IBAN formatvalidieren
<itninja description lab="regex-iban">
Validiere IBANs rein syntaktisch (ohne Mod-97-Prüfung). Akzeptiere optionale Leerzeichen zwischen Blöcken.
</itninja description>

- Beispiele: `CH93 0076 2011 6238 5295 7`, `DE89 3704 0044 0532 0130 00`
- Hinweis: Landeskürzel (2 Grossbuchstaben), 2 Ziffern Prüfsumme, restliche Zeichen: A–Z oder 0–9.

```java
    /**
     * Build a Pattern that matches IBANs syntactically with optional spaces.
     * Examples: "CH93 0076 2011 6238 5295 7", "DE89 3704 0044 0532 0130 00"
     * Note: Only format validation here, not the Mod-97 checksum.
     */
    public static Pattern buildIbanPattern() {
        // TODO: implement
        return Pattern.compile("");
    }
```

::src(src/main/java/ch/itninja/labs/regex/RegexTasks.java)

---

## Aufgabe 3 - Telefonnummern (Schweiz und international)
<itninja description lab="regex-phone">
Erkenne Telefonnummern mit optionalem Ländercode (z. B. +41) und unterschiedlichen Trennzeichen (Leerzeichen, Punkt, Bindestrich).
</itninja description>

- Beispiele: `+41 31 987 65 43`, `031 987 65 43`

```java
    /**
     * Build a Pattern for (Swiss/international) phone numbers with optional country code
     * and separators (space, dot, hyphen). Keep it reasonably permissive.
     */
    public static Pattern buildPhonePattern() {
        // TODO: implement
        return Pattern.compile("");
    }
```

::src(src/main/java/ch/itninja/labs/regex/RegexTasks.java)

---

## Aufgabe 4 - URLs extrahieren
<itninja description lab="regex-url">
Extrahiere http- und https-URLs aus einem Text, ohne ans Zeilenende zu laufen oder nachfolgende Satzzeichen mitzunehmen.
</itninja description>

- Beispiele: `https://it-ninjas.ch`, `http://example.org/test`

```java
    /**
     * Build a Pattern that captures http/https URLs without trailing punctuation.
     */
    public static Pattern buildUrlPattern() {
        // TODO: implement
        return Pattern.compile("");
    }
```

::src(src/main/java/ch/itninja/labs/regex/RegexTasks.java)

---

## Aufgabe 5 - Passwort-Policy prüfen
<itninja description lab="regex-password">
Mindestens 8 Zeichen, je 1 Klein- und Grossbuchstabe, 1 Ziffer, 1 Sonderzeichen. Prüfe mit einem einzigen Regex.
</itninja description>

- Beispiel gültig: `SecuRe!234`
- Beispiel ungültig: `password1`

```java
    /**
     * Build a Pattern enforcing: >= 8 chars, at least 1 lowercase, 1 uppercase, 1 digit, 1 symbol.
     * Hint: lookaheads.
     */
    public static Pattern buildPasswordPolicyPattern() {
        // TODO: implement
        return Pattern.compile("");
    }
```

::src(src/main/java/ch/itninja/labs/regex/RegexTasks.java)

---

### Aufgabe 6 - Schweizer Postleitzahlen (CH-PLZ)
<itninja description lab="regex-ch-plz">
Erkenne CH-Postleitzahlen (genau 4 Ziffern, keine führende 0). Beachte, dass nach der PLZ eine Ortsbezeichnung kommen
muss.
</itninja description>

- Beispiele gültig: `3007`, `1000`
- Beispiele ungültig: `0123`, `12345`

```java
    /**
     * Build a Pattern that matches Swiss postal codes (4 digits, no leading zero).
     */
    public static Pattern buildChPostalCodePattern() {
        // TODO: implement
        return Pattern.compile("");
    }
```

::src(src/main/java/ch/itninja/labs/regex/RegexTasks.java)

---

## Hinweise

- Teste deine Regex iterativ, nutze Raw-Strings (z. B. in Java `Pattern.compile("...")`) und kleine Testfälle.
- Achte darauf, bei Extraktion *nicht zu gierig* zu matchen und Mehrfachtreffer zu ermöglichen.
- Für IBANs ist eine vollständige Validierung inkl. Prüfziffernrechnung ausserhalb des Regex sinnvoll.
